<?php

header ('Location: sign.php');

?>